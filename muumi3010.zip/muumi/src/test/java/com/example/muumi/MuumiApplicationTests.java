package com.example.muumi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuumiApplicationTests {

	@Test
	void contextLoads() {
	}

}
