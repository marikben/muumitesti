package com.example.muumi;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.muumi.model.MuumiRepository;

@SpringBootApplication
public class MuumiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuumiApplication.class, args);
	}
	@Bean
	public CommandLineRunner demo(MuumiRepository repository){return(args) ->{
		
	};
}
}
