package com.example.muumi.model;

import org.springframework.data.repository.CrudRepository;

public interface KategoriaRepository extends CrudRepository <Kategoriat,Long>{

}
